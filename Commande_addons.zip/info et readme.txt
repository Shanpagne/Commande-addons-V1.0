Addon fait par : Shan

N'hésiter pas à rejoindre le serveur Médiéval RP (à la Skyrim) : Console F10 puis : connect 51.254.57.60:27260

Dossier à configurer : sv_addons.lua (suivez bien les instructions en vert pour évitez tout problème récurrent).